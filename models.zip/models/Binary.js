const constants =  require('./constant_types');
const { File_system_entity } =  require("./Entity");

class BinaryFile extends File_system_entity{
    static  MAX_BUF_FILE_SIZE = 100; 
    constructor(name,isRoot,type,parent,root, data){
        super(name,isRoot,type,parent,root);
         this._data = data;
       console.log("Binary file is created!");
    }
    get ReadFile()
    {
        return this._data;
    }
}
module.exports =  {BinaryFile}