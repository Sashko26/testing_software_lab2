const {BINARY,DIRECTORY,BUFFER,LOG_TEXT} =  require('./constant_types');
const { File_system_entity } =  require("./Entity");
class BufferFile extends File_system_entity{
    
    constructor(name,isRoot,type,parent,root){
        super(name,isRoot,type,parent,root);
       console.log("Buffer file is created!");
    }
   
    Push(data_elem)
    {
        return this.queue.push(data_elem);
    }
    Consume()
    {
        return this.queue.shift();
    }
}
module.exports =  {BufferFile}