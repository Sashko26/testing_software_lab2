const File_system_entityJS =  require('./Entity.js');
class Directory  extends File_system_entityJS.File_system_entity{
    
    constructor(name,isRoot,type,parent,root){
        super(name,isRoot,type,parent,root);
           this.listOfSubDirectories = []
           this.listOfLogFiles = []
           this.listOfBinaryFiles = []
           this.listOfBufferFiles = [] 
    }
   
    Delete()
    {
        super.Delete()
        this.listOfSubDirectories.length = 0
        this.listOfLogFiles.length = 0
        this.listOfBinaryFiles.length = 0
        this.listOfBufferFiles.length = 0
        
    }
    getListOfChildElements()
    {
        let arr_directories = this.listOfSubDirectories
        console.log(`hi huy,${arr_directories.length}`)
        let arr_BinaryFiles = this.listOfBinaryFiles
        let arr_LogFiles = this.listOfLogFiles
        let arr_BufferFiles = this.listOfLogFiles
        let sum_arr = arr_directories.concat(arr_BinaryFiles)
        console.log(`1,direct ${sum_arr.length}`)
        sum_arr = sum_arr.concat(arr_LogFiles);
        console.log(`2,direct+log ${sum_arr.length}`)
        sum_arr =  sum_arr.concat(arr_BufferFiles);
        console.log(`2,direct+buff ${sum_arr.length}`)
        return sum_arr; 
    }
    getListOfСhildElements(){
        getSubListOfChildElement(this.listOfSubDirectories,'directory');
        getSubListOfChildElement(this.listOfBinaryFiles,'binary');
        getSubListOfChildElement(this.listOfLogFiles,'logText');
        getSubListOfChildElement(this.listOfBufferFiles,'buffer');
    }
   
    MoveСhildElement(childname,newLocation){
        this.move(childname,newLocation)
    }
}

module.exports = {Directory}