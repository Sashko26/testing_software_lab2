const constants =  require('./constant_types');
class File_system_entity 
{

    constructor(name,isRoot,type,parent,root)
    {
                this.name =name
                this.isRoot=isRoot

                this.isBinary = false; 
                this.isDirectory = false;
                this.isBuffer = false;  
                this.isLogText = false; 
                if (type == constants.BINARY)
                {
                    this.isBinary = true; 
                }
                else if (type == constants.DIRECTORY)
                {
                    this.isDirectory = true; 
                }
                else if (type == constants.DIRECTORY)
                {
                    this.isBuffer = true; 
                }
                else if (type == constants.DIRECTORY)
                {
                    this.isLogText = true; 
                }
                
            if(parent!=undefined && isRoot!=true && root!=undefined)
            {   
                this.parent  = parent
                this.root = root
                let slesh = '\\'
                this.location = parent.location+slesh+parent.name
                this.parent = parent  
                console.log("penis!!!!!!!!!")
                parent.listOfSubDirectories.push(this)
            }
            else if(parent == undefined && isRoot == true && root == undefined)
            {
                this.location = '.'
            }
            else 
            {
                console.log(`Error of creating ${type}!`)
                return;
            }
            console.log(`${type} is created!`);
    }


    Delete()
    {
        let list_of_entities;
        if(type == DIRECTORY)
        {
            if(this.isRoot == true)
            {
               this.isRoot = 'deleted' 
            }
            else
            {
               list_of_entities = this.parent.listOfSubDirectories   
               this.parent=null;
            }
        }
        else if(this.isBinary)
        {
            list_of_entities = this.parent.listOfBinaryFiles;
        }
        else if(this.isLogText)
        {
            list_of_entities = this.parent.listOfLogFiles;
        }
        else if(this.isBuffer)
        {
            list_of_entities = this.parent.listOfBufferFiles;
        }
   
        if(list_of_entities)
        {
            for(let i = 0;i< list_of_entities.length;i++)
            {
                if(list_of_entities.name == this.name)
                {
                    list_of_entities.splice(i, 1);  
                }
            }
        }
        
    }


    traversalAndSearchDirectory(newLocation,subroot) 
    {
        if(subroot.listOfSubDirectories.length == 0)
        {
            return;
        }
        for(let i = 0; i < subroot.listOfSubDirectories.length; i += 1)
        {
            let elDic = subroot.listOfSubDirectories[i]
            if(elDic.location+'\\'+elDic.name == newLocation)
            {
                return elDic; 
            }  
            raversalAndSearchDirectory(newLocation,elDic)
        }
    }
    move(move_object,newLocation)
    {
            let from,to,newParent
            if(newLocation == '.')
            {
                newParent = this.root;
            }
            else
            {
                newParent = traversalAndSearchDirectory(newLocation,subroot)
            }
            if(!newParent)
            {
                console.log('this path doesn\'t exist!');
            }
            else
            {
                    for(let i=0;i<3;i++)
                    {
                            if(i==0)
                            {
                                from = this.listOfSubDirectories
                                to = newParent.listOfSubDirectories 
                            }
                            else if(i==1)
                            {
                                from = this.listOfLogFiles
                                to = newParent.listOfLogFiles 
                            }
                            else if(i==2)
                            {
                                from = this.listOfBinaryFiles
                                to = newParent.listOfBinaryFiles 
                            }
                            else if(i==3)
                            {
                                from = this.listOfBufferFiles
                                to = newParent.listOfBufferFiles 
                            }
                            for(let i=0;i<from.length;i++)
                            {
                                if(from[i].name == move_object)
                                    {
                                        to.push(from[i])
                                        from.splice(i, 1) // начиная с позиции 1, удалить 1 элемент
                                        return;
                                    }
                            }
                    }
            }
    }
   
}
module.exports = {File_system_entity};