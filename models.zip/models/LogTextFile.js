const {BINARY,DIRECTORY,BUFFER,LOG_TEXT}  = require('./constant_types');
const { File_system_entity }  = require("./Entity");
class LogTextFile extends File_system_entity{
    
    constructor(name,isRoot,type,parent,root,init_data){
       super(name,isRoot,type,parent,root);
       this._data = init_data;
       console.log("Log text file is created!");
    }
   
    set addLine(new_line) {
       this._data =`${this._data}\n${new_line}`  
      }
    get getAlldata()
    {
      return this._data;   
    }
    
 

    
    Consume()
    {
        return this.queue.shift();
    }
}
module.exports =  {LogTextFile}