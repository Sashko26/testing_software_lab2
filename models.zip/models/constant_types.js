const BINARY =  "binary";
const DIRECTORY = "directory";
const BUFFER =   "buffer";
const LOG_TEXT = "logText";

module.exports = {BINARY,DIRECTORY,BUFFER,LOG_TEXT}
